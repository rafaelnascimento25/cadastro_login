package telas;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;

@SuppressWarnings("serial")
public class TelaCadastro extends JFrame {

	  private JLabel lNome, lEmail, lCpf,lSenha, lFone, lOperadora;
	  private JButton btOk, btCancelar;
      private JTextField tfNome, tfEmail, tfSenha;
      private JComboBox cbOperadora;
      private JFormattedTextField tfCpf, tfFone;
      public String stCli, contCli, codOperadora;
      private int numLinhas, numCli;
  	
      public static  Socket socket;
  	  public static   ServerSocket ssock;
  	 public static      FileInputStream in;
      public static	  FileOutputStream fos;
      public static  InputStream is;
      public static  OutputStream out;

      
      public static ArrayList<String> dadosCliente = new ArrayList<String>();

      
       
      
      
      
   //   public static VideoFile1 vid1 = new VideoFile1();
	// construtor RadioButtonFrame adiciona JRadioButtons ao JFrame
	public TelaCadastro() {
		super("Cadastro");
		setLayout(new FlowLayout()); // configura layout do frame
	
		
		
	
		JPanel painelGeralEntrada= new JPanel(new BorderLayout());
		JPanel painelMatrizEntrada= new JPanel(new GridBagLayout());

		JPanel painelComTituloEntrada= new JPanel();
	//	painelComTituloNota.setBorder(new TitledBorder("Arquivo"));
		painelComTituloEntrada.setLayout(null);
		painelComTituloEntrada.setPreferredSize(new Dimension(495, 500));
		

		
		

		int btp = 180, btX = 100, btY = 13, btEsp = 50;	
		
		
        
		
		
		
		
		
		lNome = new JLabel("Nome:");
		
		
		lNome.setBounds(btX, btY, 50, 50);
	//	lUmPonto.setToolTipText("Nota 1");

		
		
		
		
		tfNome = new JTextField();
		
		 
		// lDoisPontos.setToolTipText("Nota 2");
		 tfNome.setBounds(btX + btEsp, btY+16, 200, 20);
		
		 
			lSenha = new JLabel("Senha:");
			
			
			lSenha.setBounds(btX-2, btY+40, 50, 50); 
		 
				 
			 
				tfSenha = new JPasswordField();
				
				 
				// lDoisPontos.setToolTipText("Nota 2");
				 tfSenha.setBounds(btX + btEsp, btY+55, 100, 20);	
		 
		 
					lCpf = new JLabel("CPF:");
					
					
					lCpf.setBounds(btX+11, btY+75, 50, 50); 
				 
						 
					try {
						MaskFormatter format = new MaskFormatter("###.###.###-##");
						tfCpf = new JFormattedTextField(format);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					
			
						
						 
						// lDoisPontos.setToolTipText("Nota 2");
						 tfCpf.setBounds(btX + btEsp, btY+92, 150, 20);	
				 
				 
							lFone = new JLabel("Fone:");
							
							
							lFone.setBounds(btX+5, btY+110, 50, 50); 
						 
							 
							try {
								MaskFormatter format2 = new MaskFormatter("(##)#####-####");
								tfFone = new JFormattedTextField(format2);
							} catch (ParseException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							 
							 
								
								
								 
								// lDoisPontos.setToolTipText("Nota 2");
								 tfFone.setBounds(btX + btEsp, btY+128, 150, 20);	 
						 
								 
									lEmail = new JLabel("Email:");
									
									
									lEmail.setBounds(btX+5, btY+150, 50, 50); 
								 
										 
									 
										tfEmail = new JTextField();
										
										 
										// lDoisPontos.setToolTipText("Nota 2");
										 tfEmail.setBounds(btX + btEsp, btY+165, 200, 20);	
						 
						 
											lOperadora = new JLabel("Operadora:");
											
											
											lOperadora.setBounds(btX-22, btY+186, 70, 50); 
				 
				 
	
											
											
											cbOperadora = new JComboBox();

											cbOperadora.addItem("");
											cbOperadora.addItem("SKY");
											cbOperadora.addItem("NET");
											cbOperadora.addItem("CLARO TV");
											cbOperadora.addItem("OI TV");
											cbOperadora.addItem("VIVO TV");

											cbOperadora.setBounds(btX + btEsp, btY+200, 100, 20);

											cbOperadora.setEditable(false);

											cbOperadora.setEnabled(true);
				 
				
				 
				 
				 
				 
	     btOk = new JButton("Ok");
		 btOk.setToolTipText("Entrar");
		 btOk.setVisible(true);
		 btOk.setBounds(130,77+btp, 85, 30);

		 
		 btOk.addActionListener(

					new ActionListener() {

						public void actionPerformed(ActionEvent event) {
		 
							

					if(tfNome.getText().equals("") || tfEmail.getText().equals("") || tfCpf.getText().equals("") 
							|| tfFone.getText().equals("")  || tfSenha.getText().equals("") || cbOperadora.getSelectedItem().equals("")) {
						
						 JOptionPane.showMessageDialog(null, "Preencha todos os campos!");
						
						
					}else {
						
						JOptionPane.showMessageDialog(null, "Cliente Cadastrado com Sucesso!");
						
						try {
							File arquivoLeitura = new File("C:\\Users\\rafao\\Documents\\TCC2\\Cliente_Offline2.txt");

							// pega o tamanho
							long tamanhoArquivo = arquivoLeitura.length();
							FileInputStream fs = new FileInputStream(arquivoLeitura);
							DataInputStream in = new DataInputStream(fs);

							LineNumberReader lineRead = new LineNumberReader(new InputStreamReader(in));
							lineRead.skip(tamanhoArquivo);
							// conta o numero de linhas do arquivo, come�a com zero, por isso adiciona 1
							numLinhas = lineRead.getLineNumber() + 1;
						//	System.out.println("O ARQUIVO CONTEM " + numLinhas + " LINHAS!!!!!!!");

							} catch (IOException e) {
							//TODO: Tratar exce��o
							}
						
						
		
						
						if (cbOperadora.getSelectedItem().equals("SKY")) {
							
							codOperadora = "11";
							
						} else if (cbOperadora.getSelectedItem().equals("NET")) {
							
							codOperadora ="21A";
						
						} if (cbOperadora.getSelectedItem().equals("CLARO TV")) {
                           codOperadora = "21B";							
						}if (cbOperadora.getSelectedItem().equals("OI TV")) {
							codOperadora = "31";
						}if (cbOperadora.getSelectedItem().equals("VIVO TV")) {
							codOperadora = "15";
						}
						
						
						
						
						
						
						
						
						
					    numCli =(numLinhas/7);
						
						if (numCli == 0) {
						
							numCli = 1;
						}else {
							numCli = numCli+1;
						}
							
							
					   dadosCliente.add("CL"+numCli);
						
						
						
						dadosCliente.add(tfNome.getText().toString());
						dadosCliente.add(tfSenha.getText().toString());
						dadosCliente.add(tfCpf.getText().toString());
						dadosCliente.add(tfFone.getText().toString());
						dadosCliente.add(tfEmail.getText().toString());
						dadosCliente.add(codOperadora);
						
						
						
						
						
						
						
						
					
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
					     File file = new File("C:\\Users\\rafao\\Documents\\TCC2\\Cliente_Offline2.txt");

				                  try  {

				                	  FileWriter fw = new FileWriter(file, true);
				          			  BufferedWriter bw = new BufferedWriter(fw);
				                	  
				                	 
				                	  
		                        //       PrintWriter gravarArq = new PrintWriter(arq);
		                               
				          			      
				          			  
				                     
				          		
				                      
						                for(int i = 0; i < dadosCliente.size(); i++){
						    	        	stCli= dadosCliente.get(i); // chama o atributo do objeto na posi��o i
						                    contCli = stCli;
						                //    contNome += "\r\n";
						    	        
						                    
						                 
						    	            bw.write(contCli);
						                
						                    bw.newLine();
							                
							                    
							                
							                }
				                  
						            	bw.close();
						    			fw.close();
				                  
				                  
				            
				             System.out.printf("Arquivo Interno gravado com sucesso!");
				             
				             
				         	
							 try {
									Thread.sleep(1000);
								     try {
										socket = new Socket("localhost", 44444);
									} catch (UnknownHostException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									} catch (IOException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								     try {
										in = new FileInputStream("C:\\Users\\rafao\\Documents\\TCC2\\Cliente_Offline2.txt");
									} catch (FileNotFoundException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								        try {
											out = socket.getOutputStream();
										} catch (IOException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
								        byte[] buf = new byte[8192];
								        int len = 0;
								        try {
											while ((len = in.read(buf)) != -1) {
											    out.write(buf, 0, len);
											}
										} catch (IOException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}

								        try {
											out.close();
										} catch (IOException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
								        try {
											in.close();
										} catch (IOException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
								  
							
									
									
									
								} catch (InterruptedException e5) {
									// TODO Auto-generated catch block
									e5.printStackTrace();
								}
			                    
				             
				             
				             
				             
				        } catch (IOException ex) {
				             System.out.printf("Falha na gravcao do arquivo interno!");
				        }
				      
						
						
						
						
						
						
						
						
						
						
						
						
						dispose();
						
						

						
						
					}
					
							
					
						}
					});
 
		 
		 
		 btCancelar = new JButton("Cancelar");
		 btCancelar .setToolTipText("Cancelar");
		 btCancelar .setVisible(true);
		 btCancelar .setBounds(290,77+btp, 85, 30);

		 
		 btCancelar .addActionListener(

					new ActionListener() {

						public void actionPerformed(ActionEvent event) {
		 

                         dispose();
					
						
					
						}
					});
		 
   
	
	   add(painelGeralEntrada, BorderLayout.NORTH); 
	   painelGeralEntrada.add(painelMatrizEntrada, BorderLayout.NORTH);
	  
	   painelMatrizEntrada.add(painelComTituloEntrada, new GridBagConstraints());
	   

	 
		 painelComTituloEntrada.add(lNome);
		 painelComTituloEntrada.add(lSenha);
		 painelComTituloEntrada.add(tfSenha);
		 painelComTituloEntrada.add(tfCpf);
		 painelComTituloEntrada.add(lCpf);
		 painelComTituloEntrada.add(tfFone);
		 painelComTituloEntrada.add(lFone);
		 painelComTituloEntrada.add(lEmail);
		 painelComTituloEntrada.add(tfEmail);
		 painelComTituloEntrada.add(btOk);
		 painelComTituloEntrada.add(btCancelar);
		 painelComTituloEntrada.add(tfNome);
		 painelComTituloEntrada.add(lOperadora);
		 painelComTituloEntrada.add(cbOperadora);
	    
  }
	
	
	public static void main(String[] args) {
        
		TelaCadastro janvb = new TelaCadastro();
		janvb.setVisible(true);
		janvb.setSize(300, 100); // configura o tamanho do frame
		// janvb.setVisible(true); // exibe o frame

		janvb.setBounds(440, 160, 360, 350);
		
		
		janvb.setResizable(false);
		janvb.setLocationRelativeTo(null);

	}
	
	
}

