package telas;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

@SuppressWarnings("serial")
public class TelaEntrada extends JFrame{

	  private JLabel lNome, lAviso, lSenha;
	  private JButton btOk, btCancelar;
      private JTextField tfNome, tfSenha;
  //	 public static VideoFile1 vid1 = new VideoFile1();
  	BufferedReader reader, reader2;
  	
  	public static ArrayList<String> dadosNomes = new ArrayList<String>();
  	public static ArrayList<String> dadosSenhas = new ArrayList<String>(); 

   
	  Socket socket;

	  
      OutputStream out;

 
  	
  	
	// construtor RadioButtonFrame adiciona JRadioButtons ao JFrame
	public TelaEntrada() {
		super("Entrada");
		setLayout(new FlowLayout()); // configura layout do frame
	
		
		
	
		JPanel painelGeralEntrada= new JPanel(new BorderLayout());
		JPanel painelMatrizEntrada= new JPanel(new GridBagLayout());

		JPanel painelComTituloEntrada= new JPanel();
	//	painelComTituloNota.setBorder(new TitledBorder("Arquivo"));
		painelComTituloEntrada.setLayout(null);
		painelComTituloEntrada.setPreferredSize(new Dimension(495, 200));
		

		
		
		
		

		int btX = 100, btY = 13, btEsp = 50;	
		
		
         lAviso = new JLabel("Entre com o seu nome e senha");
		
		
		lAviso.setBounds(165, 4, 190, 10);
		
		
		lNome = new JLabel("Nome:");
		
		
		lNome.setBounds(btX, btY, 50, 50);
	//	lUmPonto.setToolTipText("Nota 1");

		
		
		
		
		tfNome = new JTextField();
		
		 
		// lDoisPontos.setToolTipText("Nota 2");
		 tfNome.setBounds(btX + btEsp, btY+16, 200, 20);
		
		 
		 lSenha = new JLabel("Senha:");
		
		 
			
	   lSenha.setBounds(btX, btY+35, 50, 50);
		 
	   tfSenha = new JPasswordField();
	   
	   tfSenha.setBounds(btX + btEsp, btY+16+35, 100, 20);
		
		 
		 
		 btOk = new JButton("Ok");
		 btOk.setToolTipText("Entrar");
		 btOk.setVisible(true);
		 btOk.setBounds(130,107, 85, 30);

		 
		 btOk.addActionListener(

					new ActionListener() {

						public void actionPerformed(ActionEvent event) {
		 
						
							
							try {
								reader = new BufferedReader (new FileReader(new File("C:\\Users\\rafao\\Documents\\TCC2\\Cliente_Offline2.txt")));
							} catch (FileNotFoundException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							String linha;
								
							
							try {
									while ((linha = reader.readLine()) != null) {
									          if(linha.contains(tfNome.getText().toString())){
									              
									        	         dadosNomes.add(tfNome.getText().toString());
 
													 }
									        		
									        		
									       
									          
									        	 
									        	  
									        	  
									          
                                              
									          
                                               
								
                                        }
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							
							try {
								reader2 = new BufferedReader (new FileReader(new File("C:\\Users\\rafao\\Documents\\TCC2\\Cliente_Offline2.txt")));
							} catch (FileNotFoundException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							String linha2;
							
							try {
								while ((linha2 = reader2.readLine()) != null) {
								          if(linha2.contains(tfSenha.getText().toString())){
								              
								        	         dadosSenhas.add(tfSenha.getText().toString());
                                                  
												 }
								        		
								        		
								       
								          
								        	 
								        	  
								        	  
								          
                                          
								          
                                           
							
                                    }
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
							
							
							if(tfNome.getText()==null || tfNome.getText().trim().equals("")||tfSenha.getText()==null || tfSenha.getText().trim().equals("")){
								
								JOptionPane.showMessageDialog(null, "Preencha os Campos");
							}else {
								
							
								
								if( dadosNomes.contains(tfNome.getText().toString()) && (dadosSenhas.contains(tfSenha.getText().toString()))) {
								 JOptionPane.showMessageDialog(null, "Acesso Permitido");
								
					
							            
										dispose();
										
										
										  //      AplicacaoFrame.geral.add(tfNome.getText().toString());
										
										
										/*
										       vid1 = new VideoFile1();
										        
										        vid1.setSize(500, 300); // configura o tamanho do frame
												vid1.setVisible(true); // exibe o frame

												vid1.setBounds(440, 340, 320, 320);	
										
							            
									
							 			
								   	int indice = AplicacaoFrame.arr.indexOf(tfNome.getText().toString());
										  
									
										
										
										
										AplicacaoFrame.geral.add(AplicacaoFrame.arr.get(indice-1));
										
							//		System.out.println(AplicacaoFrame.arr.get(indice-1));	
										
									
										AplicacaoFrame.cadastro.add(AplicacaoFrame.arr.get(indice+5));
										AplicacaoFrame.cadastro.add(AplicacaoFrame.arr.get(indice+4));
										*/	
										
								
								}else {
								
									JOptionPane.showMessageDialog(null, "Acesso negado");
									
								
						
								}
							
							
						}
				
						}
						
						
						
					});
							
							
		 
					
							
							
							
							
							
							/*			

					if(tfNome.getText().equals("") ) {
						
						 JOptionPane.showMessageDialog(null, "O Nome n�o pode estar vazio!");
						
						
					}else {
						
						dispose();
						
						
				        AplicacaoFrame.geral.add(tfNome.getText().toString());
						
				    	 vid1 = new VideoFile1();
				        
				        vid1.setSize(500, 300); // configura o tamanho do frame
						vid1.setVisible(true); // exibe o frame

						vid1.setBounds(440, 340, 320, 320);	
						
						
						
					}
					
							
					
						}
					});
 
		 */
		 
		 btCancelar = new JButton("Cancelar");
		 btCancelar .setToolTipText("Cancelar");
		 btCancelar .setVisible(true);
		 btCancelar .setBounds(290,107, 85, 30);

		 
		 btCancelar .addActionListener(

					new ActionListener() {

						public void actionPerformed(ActionEvent event) {
		 

                         dispose();
					
						
					
						}
					});
		 
   
	
	   add(painelGeralEntrada, BorderLayout.NORTH); 
	   painelGeralEntrada.add(painelMatrizEntrada, BorderLayout.NORTH);
	  
	   painelMatrizEntrada.add(painelComTituloEntrada, new GridBagConstraints());
	   

	 
		 painelComTituloEntrada.add(lNome);
		 painelComTituloEntrada.add(lAviso);
		 painelComTituloEntrada.add(lSenha);
		 painelComTituloEntrada.add(btOk);
		 painelComTituloEntrada.add(btCancelar);
		 painelComTituloEntrada.add(tfNome);
		 painelComTituloEntrada.add(tfSenha);
	    
  }
	
	
	public static void main(String[] args) {
        
		TelaEntrada janvb = new TelaEntrada();
		janvb.setVisible(true);
		janvb.setSize(300, 300); // configura o tamanho do frame
		// janvb.setVisible(true); // exibe o frame

		janvb.setBounds(440, 340, 360, 200);

	}
	
	
}
